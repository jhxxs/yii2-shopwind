<?php

return array (
  'widgets' => 
  array (
    '_widget_505' => 
    array (
      'name' => 'df_image_ad',
      'options' => NULL,
    ),
    '_widget_130' => 
    array (
      'name' => 'df_channel2_gcategory_list',
      'options' => 
      array (
        'model_name' => '',
        'cate_id' => '0',
        'keyword' => '华为手机 数码配件 豆浆机 电饭煲 存储产品 平板电脑 取暖器 空气净化器 导航仪',
      ),
    ),
    '_widget_778' => 
    array (
      'name' => 'df_channel2_slides',
      'options' => 
      array (
        'model_name' => '',
        'ad_link_url' => 
        array (
          0 => '',
          1 => '',
          2 => '',
          3 => '',
        ),
        'ad_image_url' => 
        array (
          0 => 'data/files/mall/template/201610101221204329.jpg',
          1 => 'data/files/mall/template/201610101221204210.png',
          2 => 'data/files/mall/template/201610101221208412.png',
          3 => 'data/files/mall/template/201610101221201014.png',
        ),
        'ads' => 
        array (
          0 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610101221204329.jpg',
            'ad_link_url' => '',
          ),
          1 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610101221204210.png',
            'ad_link_url' => '',
          ),
          2 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610101221208412.png',
            'ad_link_url' => '',
          ),
          3 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610101221201014.png',
            'ad_link_url' => '',
          ),
        ),
      ),
    ),
    '_widget_188' => 
    array (
      'name' => 'df_channel2_special_goods',
      'options' => 
      array (
        'model_name' => '天天特价',
        'img_recom_id' => '15',
        'img_cate_id' => 0,
      ),
    ),
    '_widget_113' => 
    array (
      'name' => 'df_channel2_brand',
      'options' => 
      array (
        'model_name' => '品牌旗舰',
        'ad1_image_url' => 'data/files/mall/template/201610111135489502.jpg',
        'ad1_title_url' => '三星自营旗舰店,三星Note7新品开售',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201610111135482047.jpg',
        'ad2_title_url' => '自营九阳旗舰店,私享价9.9元起',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201610111135485679.jpg',
        'ad3_title_url' => 'ThinkPad自营旗舰店爆款',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201610111135482338.jpg',
        'ad4_title_url' => '自营Kindle旗舰店',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201610111135486540.jpg',
        'ad5_title_url' => '小狗旗舰店',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201610111135489229.jpg',
        'ad6_title_url' => '海尔官方自营旗舰店',
        'ad6_link_url' => '',
        'ad7_image_url' => false,
      ),
    ),
    '_widget_538' => 
    array (
      'name' => 'df_channel2_qianggou',
      'options' => 
      array (
        'model_name' => '3C · ',
        'floor_title' => '每日疯抢',
        'sub_title' => '正品行货 信誉保障',
        'img_recom_id' => '14',
        'img_cate_id' => 0,
      ),
    ),
    '_widget_150' => 
    array (
      'name' => 'df_channel2_floor1',
      'options' => 
      array (
        'model_name' => 'F1',
        'model_title' => '手机、合约机',
        'more' => '更多手机推荐',
        'keyword' => 'iPhone6s cool1 生态手机 华为 P9 三星Note7 红米note4 蓝牙耳机 以旧换新',
        'cate_ids' => '2,3,4,5,6,7,8,9,10,12,13,14,15',
        'img_recom_id_1' => '15',
        'img_cate_id' => 0,
        'ad1_image_url' => 'data/files/mall/template/201610111514294431.jpg',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201610111517323943.png',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201610111519462592.png',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201610111705236474.png',
        'ad4_link_url' => '',
        'img_recom_id_2' => '-100',
        'img_cate_id_2' => '0',
      ),
    ),
    '_widget_890' => 
    array (
      'name' => 'df_channel2_floor2',
      'options' => 
      array (
        'model_name' => 'F1 · 手机',
        'amount' => '',
        'model_color' => '#1db66f',
        'ad4_image_url' => 'data/files/mall/template/201611221619254885.jpg',
        'img_recom_id_5' => '15',
        'img_cate_id_5' => '0',
        'cate_name_1' => '热门推荐',
        'img_recom_id_1' => '14',
        'img_cate_id_1' => '0',
        'cate_name_2' => '新机发布',
        'img_recom_id_2' => '13',
        'img_cate_id_2' => '0',
        'cate_name_3' => '高性价比',
        'img_recom_id_3' => '10',
        'img_cate_id_3' => '0',
        'cate_name_4' => '口碑好货',
        'img_recom_id_4' => '9',
        'img_cate_id_4' => '0',
        'ad1_image_url' => 'data/files/mall/template/201611231102347922.jpg',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201611221619255552.jpg',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201611221619256970.jpg',
        'ad3_link_url' => '',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201611221632156725.jpg',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201611221632153182.jpg',
        'ad6_link_url' => '',
        'ad7_image_url' => 'data/files/mall/template/201611221632158955.jpg',
        'ad7_link_url' => '',
        'ad8_image_url' => 'data/files/mall/template/201611221632159212.jpg',
        'ad8_link_url' => '',
        'ad9_image_url' => 'data/files/mall/template/201611221632153955.jpg',
        'ad9_link_url' => '',
        'img_cate_id' => 0,
      ),
    ),
    '_widget_502' => 
    array (
      'name' => 'df_channel2_three_group',
      'options' => 
      array (
        'model_name' => '闪购',
        'amount' => '15',
        'title_name' => '品牌点亮生活，每天十点上新',
        'cate_name_1' => '人气卖场',
        'cate_name_2' => '今日上新',
        'cate_name_3' => '鞋包服饰',
        'images' => 
        array (
          0 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121550229463.jpg',
            'ad_link_url' => '',
          ),
          1 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121551207815.jpg',
            'ad_link_url' => '',
          ),
          2 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121551209103.jpg',
            'ad_link_url' => '',
          ),
          3 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121551203733.jpg',
            'ad_link_url' => '',
          ),
          4 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121551202163.jpg',
            'ad_link_url' => '',
          ),
          5 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121552405980.jpg',
            'ad_link_url' => '',
          ),
          6 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121552402953.jpg',
            'ad_link_url' => '',
          ),
          7 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121552405755.jpg',
            'ad_link_url' => '',
          ),
          8 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121553013010.jpg',
            'ad_link_url' => '',
          ),
          9 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121552404073.jpg',
            'ad_link_url' => '',
          ),
          10 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121554291437.jpg',
            'ad_link_url' => '',
          ),
          11 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121557018600.jpg',
            'ad_link_url' => '',
          ),
          12 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121554296412.jpg',
            'ad_link_url' => '',
          ),
          13 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121554295358.jpg',
            'ad_link_url' => '',
          ),
          14 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610121554476893.jpg',
            'ad_link_url' => '',
          ),
        ),
      ),
    ),
  ),
  'config' => 
  array (
    'top-ads' => 
    array (
      0 => '_widget_505',
    ),
    'col-1-left' => 
    array (
      0 => '_widget_130',
    ),
    'col-1-right' => 
    array (
      0 => '_widget_778',
      1 => '_widget_188',
    ),
    'col-2' => 
    array (
      0 => '_widget_113',
      1 => '_widget_538',
      2 => '_widget_150',
      3 => '_widget_890',
      4 => '_widget_502',
    ),
  ),
);