<?php

return array (
  'widgets' => 
  array (
  ),
  'config' => 
  array (
  ),
);