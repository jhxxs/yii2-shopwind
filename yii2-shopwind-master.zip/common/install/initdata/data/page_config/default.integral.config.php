<?php

return array (
  'widgets' => 
  array (
    '_widget_595' => 
    array (
      'name' => 'df_integral_article',
      'options' => 
      array (
        'cate_id' => '0',
      ),
    ),
    '_widget_204' => 
    array (
      'name' => 'df_image_ad',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/201407310739598313.gif',
        'ad_link_url' => '',
        'width' => '222',
        'height' => '100',
        'border' => '',
        'margin' => '0px 0px 10px 0px',
      ),
    ),
    '_widget_992' => 
    array (
      'name' => 'df_integral_slides',
      'options' => 
      array (
        0 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201407310838238982.jpg',
          'ad_title_url' => '标题1',
          'ad_link_url' => '',
        ),
        1 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201407310838231640.jpg',
          'ad_title_url' => '标题2',
          'ad_link_url' => '',
        ),
        2 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201407310838231841.jpg',
          'ad_title_url' => '标题3',
          'ad_link_url' => '',
        ),
        3 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201407310838231133.jpg',
          'ad_title_url' => '标题4',
          'ad_link_url' => '',
        ),
        4 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201407310838237228.jpg',
          'ad_title_url' => '标题5',
          'ad_link_url' => '',
        ),
      ),
    ),
    '_widget_519' => 
    array (
      'name' => 'df_image_ad',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/201506010730314880.jpg',
        'ad_link_url' => '',
        'width' => '1200',
        'height' => '',
        'border' => '',
        'margin' => '0px 0px 10px 0px',
        'background' => '',
        'closeButton' => '',
      ),
    ),
    '_widget_849' => 
    array (
      'name' => 'df_integral_hot',
      'options' => NULL,
    ),
    '_widget_222' => 
    array (
      'name' => 'df_image_ad',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/201407310933137440.jpg',
        'ad_link_url' => '',
        'width' => '222',
        'height' => '327',
        'border' => '',
        'margin' => '0px 0px 10px 0px',
      ),
    ),
  ),
  'config' => 
  array (
    'col1-left' => 
    array (
      0 => '_widget_595',
      1 => '_widget_204',
    ),
    'col1-right' => 
    array (
      0 => '_widget_992',
    ),
    'col-2' => 
    array (
      0 => '_widget_519',
    ),
    'col3-left' => 
    array (
      0 => '_widget_849',
      1 => '_widget_222',
    ),
  ),
);

?>