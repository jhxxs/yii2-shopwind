<?php

return array (
  'widgets' => 
  array (
    '_widget_130' => 
    array (
      'name' => 'df_channel2_gcategory_list',
      'options' => 
      array (
        'model_name' => '家用电器',
        'cate_id' => '21',
        'amount' => '5',
        'layer' => '0',
        'keyword' => '华为 小米 vivo 三星 魅族 iPhone8 iPad 联想700S',
        'model_height' => '',
      ),
    ),
    '_widget_778' => 
    array (
      'name' => 'df_channel2_slides',
      'options' => 
      array (
        'model_name' => '',
        'ad_link_url' => 
        array (
          0 => 'http://test.shopwind.net/search/goods.html?cate_id=21',
          1 => 'http://test.shopwind.net/brand/index.html',
          2 => 'http://test.shopwind.net/goods.html?id=326',
          3 => 'http://test.shopwind.net/goods.html?id=343',
        ),
        'ad_image_url' => 
        array (
          0 => 'data/files/mall/template/201610101221204329.jpg',
          1 => 'data/files/mall/template/201610101221204210.png',
          2 => 'data/files/mall/template/201610101221208412.png',
          3 => 'data/files/mall/template/201610101221201014.png',
        ),
        'ads' => 
        array (
          0 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610101221204329.jpg',
            'ad_link_url' => 'http://test.shopwind.net/search/goods.html?cate_id=21',
          ),
          1 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610101221204210.png',
            'ad_link_url' => 'http://test.shopwind.net/brand/index.html',
          ),
          2 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610101221208412.png',
            'ad_link_url' => '',
          ),
          3 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201610101221201014.png',
            'ad_link_url' => '',
          ),
        ),
      ),
    ),
    '_widget_188' => 
    array (
      'name' => 'df_channel2_special_goods',
      'options' => 
      array (
        'model_name' => '天天特价',
        'num' => '6',
        'img_recom_id' => '-100',
        'img_cate_id' => '0',
      ),
    ),
    '_widget_113' => 
    array (
      'name' => 'df_channel2_brand',
      'options' => 
      array (
        'model_name' => '品牌旗舰',
        'ad1_image_url' => 'data/files/mall/template/201610111135489502.jpg',
        'ad1_title_url' => '三星自营旗舰店,三星Note7新品开售',
        'ad1_link_url' => 'http://test.shopwind.net/brand/index.html',
        'ad2_image_url' => 'data/files/mall/template/201610111135482047.jpg',
        'ad2_title_url' => '自营九阳旗舰店,私享价9.9元起',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201610111135485679.jpg',
        'ad3_title_url' => 'ThinkPad自营旗舰店爆款',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201610111135482338.jpg',
        'ad4_title_url' => '自营Kindle旗舰店',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201610111135486540.jpg',
        'ad5_title_url' => '小狗旗舰店',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201610111135489229.jpg',
        'ad6_title_url' => '海尔官方自营旗舰店',
        'ad6_link_url' => '',
        'ad7_image_url' => false,
      ),
    ),
    '_widget_538' => 
    array (
      'name' => 'df_channel2_qianggou',
      'options' => 
      array (
        'model_name' => '3C · 数码',
        'floor_title' => '每日疯抢',
        'sub_title' => '正品行货 信誉保障',
        'img_recom_id' => '-100',
        'img_cate_id' => 0,
      ),
    ),
    '_widget_150' => 
    array (
      'name' => 'df_channel2_floor1',
      'options' => 
      array (
        'model_name' => 'F1 · 数码',
        'keyword' => 'iPhoneX|cool1|生态手机|华为|P20|三星Note7|红米note4|蓝牙耳机|以旧换新',
        'cate_ids' => '2,3,4,5,6,7,8,9,10,12,13,14,15',
        'img_recom_id_1' => '-100',
        'img_cate_id_1' => '0',
        'ad1_image_url' => 'data/files/mall/template/201610111514294431.jpg',
        'ad1_link_url' => 'http://test.shopwind.net/brand/index.html',
        'ad2_image_url' => 'data/files/mall/template/201610111517323943.png',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201610111519462592.png',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201610111705236474.png',
        'ad4_link_url' => '',
        'img_recom_id_2' => '-100',
        'img_cate_id_2' => '0',
      ),
    ),
    '_widget_890' => 
    array (
      'name' => 'df_channel2_floor2',
      'options' => 
      array (
        'model_name' => 'F2 · 数码',
        'keyword' => '照相机|摄像机 |卡片机|单反相机|莱卡|佳能|奥林巴斯',
        'cate_ids' => '2,3,4,5,6,7,8,9,10,12,13,14,15',
        'ad1_image_url' => 'data/files/mall/template/201611231102347922.jpg',
        'ad1_link_url' => '',
        'cate_name_1' => '热门推荐',
        'ad2_image_url' => 'data/files/mall/template/201611221619255552.jpg',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201805071003466347.jpg',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201805071003467491.jpg',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201805071004393279.jpg',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201805071004397909.jpg',
        'ad6_link_url' => '',
        'ad7_image_url' => 'data/files/mall/template/201805071004399052.jpg',
        'ad7_link_url' => '',
        'ad8_image_url' => 'data/files/mall/template/201805071005067617.jpg',
        'ad8_link_url' => '',
        'ad9_image_url' => 'data/files/mall/template/201805071004391194.jpg',
        'ad9_link_url' => '',
        'cate_name_2' => '新机发布',
        'img_recom_id_2' => '-100',
        'img_cate_id_2' => '21',
        'cate_name_3' => '高性价比',
        'img_recom_id_3' => '-100',
        'img_cate_id_3' => '2',
        'cate_name_4' => '口碑好货',
        'img_recom_id_4' => '-100',
        'img_cate_id_4' => '21',
        'cate_name_5' => '家用电器',
        'img_recom_id_5' => '-100',
        'img_cate_id_5' => '2',
        'cate_name_6' => '手机数码',
        'img_recom_id_6' => '-100',
        'img_cate_id_6' => '0',
      ),
    ),
    '_widget_502' => 
    array (
      'name' => 'df_channel2_three_group',
      'options' => 
      array (
        'model_name' => '品牌购',
        'cate_name_1' => '人气卖场',
        'ad1_image_url_1' => 'data/files/mall/template/201805071007111123.jpg',
        'ad1_link_url_1' => '',
        'ad1_image_url_2' => 'data/files/mall/template/201805071007115752.jpg',
        'ad1_link_url_2' => '',
        'ad1_image_url_3' => 'data/files/mall/template/201805071011427813.jpg',
        'ad1_link_url_3' => '',
        'ad1_image_url_4' => 'data/files/mall/template/201805071007116895.jpg',
        'ad1_link_url_4' => '',
        'ad1_image_url_5' => 'data/files/mall/template/201805071007118039.jpg',
        'ad1_link_url_5' => '',
        'cate_name_2' => '今日上新',
        'ad2_image_url_1' => 'data/files/mall/template/201805071009256365.jpg',
        'ad2_link_url_1' => '',
        'ad2_image_url_2' => 'data/files/mall/template/201805071009257508.jpg',
        'ad2_link_url_2' => '',
        'ad2_image_url_3' => 'data/files/mall/template/201805071010576663.jpg',
        'ad2_link_url_3' => '',
        'ad2_image_url_4' => 'data/files/mall/template/201805071009258651.jpg',
        'ad2_link_url_4' => '',
        'ad2_image_url_5' => 'data/files/mall/template/201805071009254280.jpg',
        'ad2_link_url_5' => '',
        'cate_name_3' => '鞋包服饰',
        'ad3_image_url_1' => 'data/files/mall/template/201805071011565683.jpg',
        'ad3_link_url_1' => '',
        'ad3_image_url_2' => 'data/files/mall/template/201805071010577807.jpg',
        'ad3_link_url_2' => '',
        'ad3_image_url_3' => 'data/files/mall/template/201805071010573435.jpg',
        'ad3_link_url_3' => '',
        'ad3_image_url_4' => 'data/files/mall/template/201805071010574578.jpg',
        'ad3_link_url_4' => '',
        'ad3_image_url_5' => 'data/files/mall/template/201805071011423442.jpg',
        'ad3_link_url_5' => '',
      ),
    ),
  ),
  'config' => 
  array (
    'col-1-left' => 
    array (
      0 => '_widget_130',
    ),
    'col-1-right' => 
    array (
      0 => '_widget_778',
      1 => '_widget_188',
    ),
    'col-2' => 
    array (
      0 => '_widget_113',
      1 => '_widget_538',
      2 => '_widget_150',
      3 => '_widget_890',
      4 => '_widget_502',
    ),
  ),
  'tmp' => 
  array (
    '_widget_110' => 
    array (
      'options' => 
      array (
        'model_name' => '限时秒杀',
        'img_recom_id' => '-100',
        'img_cate_id' => '0',
      ),
    ),
  ),
);