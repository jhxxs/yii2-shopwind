<?php

return array (
  'widgets' => 
  array (
    '_widget_693' => 
    array (
      'name' => 'df_image_ad',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/20181212172931441.jpg',
        'ad_link_url' => 'http://test.shopwind.net/channel/index.html?id=154318852528',
        'width' => '',
        'height' => '80',
        'border' => '0',
        'margin' => '0',
        'background' => 'rgb(219, 0, 28)',
        'closeButton' => '1',
      ),
    ),
    '_widget_684' => 
    array (
      'name' => 'df_slides',
      'options' => 
      array (
        'effect' => 'fade',
        'autoplay' => 'true',
        'ads' => 
        array (
          0 => 
          array (
            'ad_image_url' => 'data/files/mall/template/20181211101259917.jpg',
            'ad_link_url' => 'http://test.shopwind.net/channel/index.html?id=154318852528',
            'ad_bgcolor' => '#1e0954',
          ),
          1 => 
          array (
            'ad_image_url' => 'data/files/mall/template/20181211112615856.png',
            'ad_link_url' => 'http://test.shopwind.net/channel/index.html?id=154318705971',
            'ad_bgcolor' => '#80d8ff',
          ),
        ),
      ),
    ),
    '_widget_849' => 
    array (
      'name' => 'df_user',
      'options' => 
      array (
        'model1_title' => '商城帮助',
        'cate_id_1' => '1',
        'model2_title' => '入驻指南',
        'cate_id_2' => '6',
      ),
    ),
    '_widget_423' => 
    array (
      'name' => 'df_seckill',
      'options' => 
      array (
        'img_recom_id' => '-100',
        'img_cate_id' => '0',
        'num' => '5',
      ),
    ),
    '_widget_905' => 
    array (
      'name' => 'df_need_channel',
      'options' => 
      array (
        'ad1_image_url' => 'data/files/mall/template/201709201020512809.png',
        'ad1_link_url' => 'http://test.shopwind.net/search/goods.html?cate_id=21',
        'model1_title' => '优质新品|专注生活美学',
        'model_style1' => 'mi',
        'ad2_image_url' => 'data/files/mall/template/201709201022285977.png',
        'ad2_link_url' => 'http://test.shopwind.net/goods.html?id=343',
        'model2_title' => '潮流女装|春装流行款抢购',
        'model_style2' => 'danh',
        'ad3_image_url' => 'data/files/mall/template/201709201022288521.png',
        'ad3_link_url' => 'http://test.shopwind.net/store/index.html?id=2',
        'model3_title' => '人气美鞋|新外貌“鞋”会',
        'model_style3' => 'huang',
        'ad4_image_url' => 'data/files/mall/template/201709201022289922.png',
        'ad4_link_url' => 'http://test.shopwind.net/goods.html?id=326',
        'model4_title' => '品牌精选|潮牌尖货 初春换新',
        'model_style4' => 'zi',
        'ad5_image_url' => 'data/files/mall/template/201709201022285808.png',
        'ad5_link_url' => 'http://test.shopwind.net/brand/index.html',
        'model5_title' => '护肤彩妆|春妆必买清单 低至3折',
        'model_style5' => 'danzi',
        'ad0_image_url' => false,
      ),
    ),
    '_widget_474' => 
    array (
      'name' => 'df_bag_brand',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/201709261757382322.jpg',
        'ad_link_url' => 'http://test.shopwind.net/brand/index.html',
      ),
    ),
    '_widget_132' => 
    array (
      'name' => 'df_clothing',
      'options' => 
      array (
        'model_name' => '韩版女装系列',
        'model_style' => 'qing',
        'ad1_image_url' => 'data/files/mall/template/201709201600102800.jpg',
        'ad1_link_url' => 'http://test.shopwind.net/brand/index.html',
        'ad2_image_url' => 'data/files/mall/template/201709201600108830.jpg',
        'ad2_link_url' => 'http://test.shopwind.net/search/goods.html?cate_id=21',
        'ad3_image_url' => 'data/files/mall/template/201709201600105860.jpg',
        'ad3_link_url' => 'http://test.shopwind.net/store/index.html?id=2',
        'ad4_image_url' => 'data/files/mall/template/201709201559279557.jpg',
        'ad4_link_url' => 'http://test.shopwind.net/channel/index.html?id=154318852528',
        'ad5_image_url' => 'data/files/mall/template/201709201559277730.jpg',
        'ad5_link_url' => 'http://test.shopwind.net/goods.html?id=315',
        'tab1_title' => '精品推荐',
        'ad6_image_url' => 'data/files/mall/template/201709201535256148.jpg',
        'ad6_link_url' => 'http://test.shopwind.net/channel/index.html?id=154318705971',
        'model6_title' => '毛衣|满100减10',
        'ad7_image_url' => 'data/files/mall/template/201709201535253177.png',
        'ad7_link_url' => 'http://test.shopwind.net/goods.html?id=326',
        'model7_title' => '随意搭|来潮我看',
        'ad8_image_url' => 'data/files/mall/template/201709201535258322.png',
        'ad8_link_url' => 'http://test.shopwind.net/search/goods.html?cate_id=63',
        'model8_title' => '外套|大牌抢好货',
        'ad9_image_url' => 'data/files/mall/template/201709201602444201.jpg',
        'ad9_link_url' => 'http://test.shopwind.net/integral/index.html',
        'model9_title' => '连衣裙|春季流行款抢购',
        'ad10_image_url' => 'data/files/mall/template/201709201602545278.jpg',
        'ad10_link_url' => 'http://test.shopwind.net/limitbuy/index.html',
        'model10_title' => '男帽|新款鸭舌帽',
        'ad11_image_url' => 'data/files/mall/template/201709221648508994.png',
        'ad11_link_url' => 'http://test.shopwind.net/brand/index.html',
        'model11_title' => '女装内衣馆|盛夏新搭时尚',
        'tab2_title' => '新款女装',
        'img_recom_id_2' => '-100',
        'img_cate_id_2' => '21',
        'tab3_title' => '服饰配件',
        'img_recom_id_3' => '-100',
        'img_cate_id_3' => '2',
        'tab4_title' => '女士内衣',
        'img_recom_id_4' => '-100',
        'img_cate_id_4' => '21',
        'tab5_title' => '潮牌男装',
        'img_recom_id_5' => '-100',
        'img_cate_id_5' => '0',
      ),
    ),
    '_widget_650' => 
    array (
      'name' => 'df_fl_brand',
      'options' => NULL,
    ),
    '_widget_297' => 
    array (
      'name' => 'df_electrical',
      'options' => 
      array (
        'model_name' => '箱包鞋帽系列',
        'model_style' => 'cheng',
        'ad1_image_url' => 'data/files/mall/template/201709210905555593.jpg',
        'ad1_link_url' => 'http://test.shopwind.net/store/index.html?id=2',
        'ad2_image_url' => 'data/files/mall/template/201709210905555996.jpg',
        'ad2_link_url' => 'http://test.shopwind.net/brand/index.html',
        'ad3_image_url' => 'data/files/mall/template/201709210905553025.jpg',
        'ad3_link_url' => 'http://test.shopwind.net/search/goods.html?cate_id=21',
        'ad4_image_url' => 'data/files/mall/template/201709210905558484.jpg',
        'ad4_link_url' => 'http://test.shopwind.net/goods.html?id=326',
        'ad5_image_url' => 'data/files/mall/template/201709210905557542.jpg',
        'ad5_link_url' => 'http://test.shopwind.net/integral/index.html',
        'tab1_title' => '精品推荐',
        'ad6_image_url' => 'data/files/mall/template/201709210920332883.png',
        'ad6_link_url' => 'http://test.shopwind.net/channel/index.html?id=154318705971',
        'model6_title' => '防水斜挎包|商城自营闪电发货',
        'ad7_image_url' => 'data/files/mall/template/201709210920331370.png',
        'ad7_link_url' => 'http://test.shopwind.net/goods.html?id=315',
        'model7_title' => '欧时纳女包|跨万店三免一',
        'ad8_image_url' => 'data/files/mall/template/201709210920332771.png',
        'ad8_link_url' => 'http://test.shopwind.net/goods.html?id=332',
        'model8_title' => '大牌精选|满199减100',
        'ad9_image_url' => 'data/files/mall/template/201709210920332143.png',
        'ad9_link_url' => 'http://test.shopwind.net/channel/index.html?id=154318852528',
        'model9_title' => '纪梵希|大牌上新',
        'ad10_image_url' => 'data/files/mall/template/201709210923253273.jpg',
        'ad10_link_url' => 'http://test.shopwind.net/search/goods.html?cate_id=63',
        'model10_title' => '阿迪达斯|新款女鞋上线',
        'ad11_image_url' => 'data/files/mall/template/201709210923253216.jpg',
        'ad11_link_url' => 'http://test.shopwind.net/goods.html?id=315',
        'model11_title' => 'LUGAV奢侈品|男士商务皮鞋',
        'tab2_title' => '功能箱包',
        'img_recom_id_2' => '-100',
        'img_cate_id_2' => '21',
        'tab3_title' => '流行男鞋',
        'img_recom_id_3' => '-100',
        'img_cate_id_3' => '2',
        'tab4_title' => '时尚女鞋',
        'img_recom_id_4' => '-100',
        'img_cate_id_4' => '0',
        'tab5_title' => '',
        'img_recom_id_5' => '-100',
        'img_cate_id_5' => '2',
      ),
    ),
    '_widget_760' => 
    array (
      'name' => 'df_master',
      'options' => 
      array (
        'model_name' => '还有更多商品',
        'ad1_image_url' => 'data/files/mall/template/201709211012151189.png',
        'ad1_link_url' => 'http://test.shopwind.net/brand/index.html',
        'model1_title' => '纯棉质品|把好货带回家',
        'model_style1' => 'qing',
        'ad2_image_url' => 'data/files/mall/template/201709211015174199.png',
        'ad2_link_url' => 'http://test.shopwind.net/search/goods.html?cate_id=21',
        'model2_title' => '新品沙发|热卖中',
        'model_style2' => 'danzi',
        'ad3_image_url' => 'data/files/mall/template/201709211015178201.png',
        'ad3_link_url' => 'http://test.shopwind.net/search/goods.html?cate_id=63',
        'model3_title' => '团购热卖|都是好货',
        'model_style3' => 'danh',
        'ad4_image_url' => 'data/files/mall/template/201709211015177573.png',
        'ad4_link_url' => 'http://test.shopwind.net/channel/index.html?id=154318705971',
        'model4_title' => '舒适童鞋|帮宝宝学走路',
        'model_style4' => 'lan',
        'ad5_image_url' => 'data/files/mall/template/201709211015176945.png',
        'ad5_link_url' => 'http://test.shopwind.net/store/index.html?id=2',
        'model5_title' => '双十二运动鞋|品牌直降',
        'model_style5' => 'tao',
      ),
    ),
    '_widget_554' => 
    array (
      'name' => 'df_store',
      'options' => 
      array (
        'model_name' => '热门商铺',
        'ad1_image_url' => 'data/files/mall/template/201709261649278403.jpg',
        'ad1_storeId' => '2',
        'ad1_title' => '女装时尚内衣',
        'ad2_image_url' => 'data/files/mall/template/201709261649276004.jpg',
        'ad2_storeId' => '2',
        'ad2_title' => '夏季潮流女装馆',
        'ad3_image_url' => 'data/files/mall/template/201709261649272462.jpg',
        'ad3_storeId' => '2',
        'ad3_title' => '秋季休闲女装馆',
        'ad4_image_url' => 'data/files/mall/template/201709261649272406.jpg',
        'ad4_storeId' => '2',
        'ad4_title' => '校园风格女装馆',
      ),
    ),
    '_widget_455' => 
    array (
      'name' => 'df_goods_list',
      'options' => 
      array (
        'model_name' => '猜你喜欢',
        'img_recom_id' => '-100',
        'img_cate_id' => '0',
        'num' => '30',
      ),
    ),
  ),
  'config' => 
  array (
    'top-ads' => 
    array (
      0 => '_widget_693',
    ),
    'col-1-r-l' => 
    array (
      0 => '_widget_684',
    ),
    'col-1-r-r' => 
    array (
      0 => '_widget_849',
    ),
    'col-3' => 
    array (
      0 => '_widget_423',
      1 => '_widget_905',
      2 => '_widget_474',
      3 => '_widget_132',
      4 => '_widget_650',
      5 => '_widget_297',
      6 => '_widget_760',
      7 => '_widget_554',
      8 => '_widget_455',
    ),
  ),
);
