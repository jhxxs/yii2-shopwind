<?php

return array (
  'widgets' => 
  array (
    '_widget_166' => 
    array (
      'name' => 'df_image_ad',
      'options' => NULL,
    ),
    '_widget_263' => 
    array (
      'name' => 'df_channel1_category',
      'options' => 
      array (
        'model_name' => '女装',
        'cate_id' => '185',
      ),
    ),
    '_widget_541' => 
    array (
      'name' => 'df_channel1_full_slides',
      'options' => 
      array (
        'model_name' => '',
        'ad_image_url' => 
        array (
          0 => 'data/files/mall/template/201406180919003534.jpg',
          1 => 'data/files/mall/template/201406180919006480.jpg',
          2 => 'data/files/mall/template/201406180919004347.jpg',
          3 => 'data/files/mall/template/201406190643016989.jpg',
          4 => 'data/files/mall/template/201406190642061868.jpg',
        ),
        'ad_link_url' => 
        array (
          0 => '',
          1 => '',
          2 => '',
          3 => '',
          4 => '',
        ),
        'ads' => 
        array (
          0 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201406180919003534.jpg',
            'ad_link_url' => '',
          ),
          1 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201406180919006480.jpg',
            'ad_link_url' => '',
          ),
          2 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201406180919004347.jpg',
            'ad_link_url' => '',
          ),
          3 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201406190643016989.jpg',
            'ad_link_url' => '',
          ),
          4 => 
          array (
            'ad_image_url' => 'data/files/mall/template/201406190642061868.jpg',
            'ad_link_url' => '',
          ),
        ),
      ),
    ),
    '_widget_473' => 
    array (
      'name' => 'df_channel1_six_images',
      'options' => 
      array (
        'model_name' => '猜你喜欢的品牌',
        'ad1_image_url' => 'data/files/mall/template/201406190411011696.jpg',
        'ad1_title_url' => '钻宝源（BEASONE）',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201406190411013621.jpg',
        'ad2_title_url' => '周生生',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201406190411019684.jpg',
        'ad3_title_url' => '笛凡（DF）',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201406190411015569.jpg',
        'ad4_title_url' => '一搏千金',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201406190414312141.jpg',
        'ad5_title_url' => '阿迪达斯（Adidas）',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201406190414319629.jpg',
        'ad6_title_url' => '衣然呈品',
        'ad6_link_url' => '',
      ),
    ),
    '_widget_908' => 
    array (
      'name' => 'df_channel1_three_image_ads',
      'options' => 
      array (
        'model_name' => '精选活动',
        'ad1_image_url' => 'data/files/mall/template/201406190609399054.jpg',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201406190609394087.jpg',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201406190609391688.jpg',
        'ad3_link_url' => '',
      ),
    ),
    '_widget_351' => 
    array (
      'name' => 'df_channel1_floor1',
      'options' => 
      array (
        'model_name' => '女装',
        'keywords' => '连衣裙 裤子 T恤 真丝 雪纺衫 衬衫 针织衫 卫衣',
        'ad1_image_url' => 'data/files/mall/template/201406190827287573.jpg',
        'ad1_title_url' => '哥弟 惊天5折,欢庆618',
        'ad1_link_url' => '1',
        'ad2_image_url' => 'data/files/mall/template/201406190846367515.jpg',
        'ad2_title_url' => '韩都衣舍 全场五折 满400减200',
        'ad2_link_url' => '2',
        'ad3_image_url' => 'data/files/mall/template/201406190827281945.jpg',
        'ad3_title_url' => '裂帛 618巅峰时刻！满299减80！',
        'ad3_link_url' => '3',
        'ad4_image_url' => 'data/files/mall/template/201406190827283918.jpg',
        'ad4_title_url' => '粉红大布娃娃 全场低至2折 海量特供59元起 ！',
        'ad4_link_url' => '4',
        'ad5_image_url' => 'data/files/mall/template/201406190827285698.jpg',
        'ad5_title_url' => '魅惑格调 女装大趴',
        'ad5_link_url' => '5',
        'ad6_image_url' => 'data/files/mall/template/201406190827287356.jpg',
        'ad6_title_url' => '女装大趴 2折起',
        'ad6_link_url' => '6',
      ),
    ),
    '_widget_282' => 
    array (
      'name' => 'df_channel1_floor1',
      'options' => 
      array (
        'model_name' => '男装',
        'keywords' => '夹克 衬衫 针织衫 牛仔裤 T恤 卫衣 西服 休闲裤 ',
        'ad1_image_url' => 'data/files/mall/template/201406200246121271.jpg',
        'ad1_title_url' => '太平鸟男装 五折封顶，满499减100',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201406200246123018.jpg',
        'ad2_title_url' => '九牧王 全场5折封顶 499减50,899减100',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201406200246123534.jpg',
        'ad3_title_url' => '马克华菲 618paaty on 全场低至1折',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201406200246129564.jpg',
        'ad4_title_url' => '太子龙 618狂欢盛宴 领券满349减50',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201406200246127165.jpg',
        'ad5_title_url' => '柒牌',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201406200246122737.jpg',
        'ad6_title_url' => '雅戈尔',
        'ad6_link_url' => '',
      ),
    ),
    '_widget_112' => 
    array (
      'name' => 'df_channel1_floor2',
      'options' => 
      array (
        'model_name' => '鞋靴箱包',
        'keywords' => '男鞋时尚 通勤单鞋 618大促 男士手包 大牌精选',
        'ad1_image_url' => 'data/files/mall/template/201406200301211853.jpg',
        'ad1_title_url' => '百丽女鞋5折封顶 折后再满200减30，满300减60',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201406200301211797.jpg',
        'ad2_title_url' => '达芙妮618专场 全场5折封顶再满减',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201406200301219840.jpg',
        'ad3_title_url' => '618男包专场 全场低至1折',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201406200301215726.jpg',
        'ad4_title_url' => 'GEOX五折封顶再满减 5折封顶',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201406200301219156.jpg',
        'ad5_title_url' => '骆驼男鞋 5折封顶',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201406200301217071.jpg',
        'ad6_title_url' => '女鞋PARTYON 6.18元抢！',
        'ad6_link_url' => '',
        'ad7_image_url' => 'data/files/mall/template/201406200326052076.jpg',
        'ad7_title_url' => '618男包专场  全场低至1折',
        'ad7_link_url' => '',
        'ad8_image_url' => 'data/files/mall/template/201406200326052020.jpg',
        'ad8_title_url' => '618全民疯抢箱包-满300减100',
        'ad8_link_url' => '',
      ),
    ),
    '_widget_176' => 
    array (
      'name' => 'df_channel1_floor1',
      'options' => 
      array (
        'model_name' => '内衣童装',
        'keywords' => '光面文胸 无痕内裤 真丝 情侣睡衣 商务男袜 船袜 男内裤 泳装 ',
        'ad1_image_url' => 'data/files/mall/template/201406200332138470.jpg',
        'ad1_title_url' => '爱慕 惊喜High翻天全场低至2折',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201406200332133471.jpg',
        'ad2_title_url' => '秋鹿 秋鹿巅峰大促五折封顶',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201406200332138358.jpg',
        'ad3_title_url' => 'NewBalance儿童 全场低至5折满300立减50',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201406200332138165.jpg',
        'ad4_title_url' => '十月妈咪 活泼、时尚、健康、舒适',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201406200333421368.jpg',
        'ad5_title_url' => '文胸满200减100',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201406200333425941.jpg',
        'ad6_title_url' => '古今闪购',
        'ad6_link_url' => '',
      ),
    ),
    '_widget_606' => 
    array (
      'name' => 'df_channel1_floor2',
      'options' => 
      array (
        'model_name' => '珠宝配饰',
        'keywords' => '珍珠项链 水晶手链 黄金手链 小叶紫檀 光学镜架/镜片 ',
        'ad1_image_url' => 'data/files/mall/template/201406200338103098.jpg',
        'ad1_title_url' => 'T400 五折封顶满299再减50',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201406200338107100.jpg',
        'ad2_title_url' => '源生 折后满1000减168',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201406200338107043.jpg',
        'ad3_title_url' => '珠宝首饰巅峰盛宴 新品五折封顶',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201406200338106987.jpg',
        'ad4_title_url' => '鑫万福 品牌特卖低至3折',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201406200338105506.jpg',
        'ad5_title_url' => '周大福 全场最高减免20%',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201406200338106907.jpg',
        'ad6_title_url' => '每日一秒低至61.8 配饰专场',
        'ad6_link_url' => '',
        'ad7_image_url' => 'data/files/mall/template/201406200341198844.jpg',
        'ad7_title_url' => '派丽蒙太阳镜，仅此一天，99元抢购！',
        'ad7_link_url' => '',
        'ad8_image_url' => 'data/files/mall/template/201406200341191501.jpg',
        'ad8_title_url' => '备拼618  满减后再用券',
        'ad8_link_url' => '',
      ),
    ),
    '_widget_545' => 
    array (
      'name' => 'df_channel1_floor1',
      'options' => 
      array (
        'model_name' => '运动户外',
        'keywords' => '跑鞋 骑行服 冲锋衣 登山鞋 户外背包 军迷',
        'ad1_image_url' => 'data/files/mall/template/201406200349097487.jpg',
        'ad1_title_url' => 'JackWolfskin 5折封顶，再满减！',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/201406200349099403.jpg',
        'ad2_title_url' => '全场5折 胜道店庆狂欢',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/201406200349099613.jpg',
        'ad3_title_url' => '运动大牌狂欢 精品5折新品6.5折',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/201406200349095499.jpg',
        'ad4_title_url' => '骑行服618特惠 骑行装备全场4折起',
        'ad4_link_url' => '',
        'ad5_image_url' => 'data/files/mall/template/201406200351533267.jpg',
        'ad5_title_url' => '满600减100 Party on',
        'ad5_link_url' => '',
        'ad6_image_url' => 'data/files/mall/template/201406200351533211.jpg',
        'ad6_title_url' => '酷锐运动全场300-20',
        'ad6_link_url' => '',
      ),
    ),
  ),
  'config' => 
  array (
    'top-ads' => 
    array (
      0 => '_widget_166',
    ),
    'float-layer' => 
    array (
      0 => '_widget_263',
    ),
    'full-width-area' => 
    array (
      0 => '_widget_541',
    ),
    'col-3-left' => 
    array (
      0 => '_widget_473',
    ),
    'col-3-right' => 
    array (
      0 => '_widget_908',
    ),
    'width-area' => 
    array (
      0 => '_widget_351',
      1 => '_widget_282',
      2 => '_widget_112',
      3 => '_widget_176',
      4 => '_widget_606',
      5 => '_widget_545',
    ),
  ),
);