<?php

return array (
  'widgets' => 
  array (
    '_widget_164' => 
    array (
      'name' => 'df_image_ad',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/201608051534251029.png',
        'ad_link_url' => '',
        'width' => '',
        'height' => '',
        'border' => '',
        'margin' => '',
        'background' => '#FFF3B5',
        'closeButton' => '',
      ),
    ),
  ),
  'config' => 
  array (
    'login_left' => 
    array (
      0 => '_widget_164',
    ),
  ),
);