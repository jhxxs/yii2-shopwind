<?php

//下载编码表格 https://api.kuaidi100.com/manager/openapi/download/kdbm.do

return array(
    'yuantong'          =>    '圆通速递',
    'yunda'             =>    '韵达快递',
    'shentong'          =>    '申通快递',
    'jtexpres'          =>    '极兔速递',
    'zhongton'          =>    '中通快递',
    'youzhengguonei'    =>    '邮政快递包裹',
    'shunfeng'          =>    '顺丰速运',
    'ems'               =>    'EMS',
    'jd'                =>    '京东物流',
    //'youzhengbk'        =>    '邮政标准快递',
    'fengwang'          =>    '丰网速运',
    'debangkuaidi'      =>    '德邦快递',
    //'debangwuliu'       =>    '德邦',
    'zhongtongkuaiyun'  =>    '中通快',
    'feibaokuaidi'      =>    '飞豹快递',
    'annengwuliu'       =>    '安能快运',
    //'ctoexp'            =>    '泰国中通CTO',
    //'huitongkuaidi'     =>    '百世快递',
    'ewe'               =>    'EWE全球快递',
    //'danniao'           =>    '丹鸟',
);