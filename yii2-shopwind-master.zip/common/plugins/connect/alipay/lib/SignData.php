<?php

namespace common\plugins\connect\alipay\lib;

class SignData {

    public $signSourceData=null;


    public $sign=null;

} 