<?php

return array(
    'user_manage' => '用户管理',
    'admin_manage' => '管理员管理',
    'store_manage' => '店铺管理',
    'goods_manage' => '商品管理',
    'distribute_manage' => '分销商管理',
    'order_manage' => '订单管理',
    'article_manage' => '文章管理',
    'username' => '用户名',
    'system_admin_drop' => '该帐号为系统管理员,不得删除',
    'choose_admin' => '请选择管理员',
    'drop_ok' => '删除管理员成功',
    'drop_failed' => '删除管理员失败',
    'system_admin_edit' => '该帐号为系统管理员，不得编辑！',
    'edit_ok' =>'管理员编辑成功',
    'already_admin' =>'该帐号已经是管理员',
	'phone_mob' => '手机',
    'admin_add' => '添加管理员',
    'add_ok' => '添加管理员成功',
    'priv_edit' => '编辑权限',
    'deposit' => '资产',
);