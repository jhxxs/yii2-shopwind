<?php

return array(
    'promote_list' => '营销工具'
);