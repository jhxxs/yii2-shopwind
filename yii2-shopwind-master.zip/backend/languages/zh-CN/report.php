<?php
return array(
	'report_goods' => '被举报的商品',
    'report_store' => '被举报的店铺',
    'content' => '举报内容',
    'no_such_item' => '没有该举报项',
    'cannot_drop' => '管理员已审核，不能删除该项',
	'username' => '举报人',
	'report_list' => '举报管理',
	'add_time' => '举报时间',
	'verify_ok' => '处理完成，并已短消息通知举报人',
	'verify_empty' => '处理意见不能为空',
	'verify_content' => '请提交处理意见',
	'batch_verify' => '批量审核',
	'report_handle' => '举报信息，管理员已处理',
	'report_manage' => '举报管理',
);