<?php
return array(
    'cache_redis' => 'Redis缓存',
    'cache_memcache' => 'MemCache缓存',
    'cache_file'  => '文件缓存',
    'cache_setting' => '缓存设置',
    'hostname' => '主机地址（hostname）',
    'hostname_desc' => '如果是本地服务，windows建议使用127.0.0.1',
    'port' => '端口号（port）',
    'port_desc' => '一般不需要修改',
    'password' => 'Redis密码',
    'status' => '是否启用',
    'cache_path' => '缓存目录',
    'cache_path_desc' => '缓存文件存储目录，暂不支持修改',
    'extension_v' => 'PHP拓展版本',
);