<?php

return array(
    'clear_cache' => '更新缓存',
    'clear_cache_ok' => '缓存更新成功',

    'reminds.region' => '您还没有<span>添加地区</span>，请到 <a href="%s"><span style="color:#f60;">设置/地区设置</span></a> 中添加',
	'reminds.payment'  => '您还没有<span>启用支付方式</span>，请到 <a href="%s"><span style="color:#f60;">插件/支付插件</span></a> 中启用',
 	'reminds.gcategory' => '您还没有<span>添加商品分类</span>，请到 <a href="%s"><span style="color:#f60;">商品/分类管理</span></a> 中添加',
	'reminds.report' => '您有 <b style="color:#f60;">%s</b> 条举报信息待处理，请到 <a href="%s"><span style="color:#f60;">网站/举报管理</span></a> 中处理',
	'reminds.refund' => '您有 <b style="color:#f60;">%s</b> 条退款申请待处理，请到 <a href="%s"><span style="color:#f60;">订单/退款售后</span></a> 中处理',
	'reminds.apply' => '您有 <b style="color:#f60;">%s</b> 条店铺申请待审核，请到 <a href="%s"><span style="color:#f60;">店铺/店铺管理</span></a> 中处理',
);