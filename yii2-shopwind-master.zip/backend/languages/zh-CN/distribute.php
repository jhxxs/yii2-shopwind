<?php

return array(
	'created' 		=> '申请时间',
	'phone_mob'		=> '联系电话',
	'parent'		=> '邀请人',
	'status' 		=> '状态',
	'applying' 		=> '待审核',
	'detail'		=> '详情',
	'remark'		=> '审核说明',
	'agree' 		=> '同意',
	'agree_ok'		=> '您已同意该分销商申请',
	'reject'		=> '拒绝',
	'reject_ok'		=> '您已拒绝了该分销商申请',
	'reject_reason' => '拒绝原因',
	'input_reason'  => '请填写拒绝原因',
	'nopass'		=> '未通过',
	'handle_error'	=> '分销商不存在或状态不允许审核',
);